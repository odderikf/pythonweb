import math
print('1+3*3',1+3*3, sep=' = ')
print('1+(5*3)',1+(5*3), sep=' = ')
print('(1+4)*3', (1+4)*3, sep=' = ')
r = 8
print('r = 8')
print('areal:', math.pi * r**2)
print('omkrets:', math.pi * 2*r)
