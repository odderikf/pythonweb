print(input('Hva er navnet ditt?\n')+'!')
