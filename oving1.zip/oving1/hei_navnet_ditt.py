print('hei, Odd-Erik!')
