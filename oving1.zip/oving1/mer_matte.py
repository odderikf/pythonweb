a = input('gi meg ett tall\n')
b = input('gi meg enda ett\n')
print(a,'+',b,'=',float(a)+float(b))
